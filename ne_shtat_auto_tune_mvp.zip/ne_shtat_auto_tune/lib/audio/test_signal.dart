import 'dart:math' as math;
import 'dart:typed_data';
import 'wav_utils.dart';

class TestSignal {
  /// Generates a low-level logarithmic sweep WAV. Keep the vehicle parked and
  /// volume modest; the app must never be used while driving.
  static Uint8List logarithmicSweepWav({
    int sampleRate = 48000,
    double durationSeconds = 8,
    double startHz = 30,
    double endHz = 16000,
    double amplitude = 0.12,
  }) {
    final count = (sampleRate * durationSeconds).round();
    final samples = List<int>.filled(count, 0);
    final logRatio = math.log(endHz / startHz);
    final k = durationSeconds / logRatio;
    for (var i = 0; i < count; i++) {
      final t = i / sampleRate;
      final phase = 2 * math.pi * startHz * k * (math.exp(t / k) - 1);
      final fadeIn = (t / 0.08).clamp(0.0, 1.0);
      final remaining = durationSeconds - t;
      final fadeOut = (remaining / 0.12).clamp(0.0, 1.0);
      final envelope = math.min(fadeIn, fadeOut);
      samples[i] = (32767 * amplitude * envelope * math.sin(phase)).round();
    }
    return WavUtils.pcm16MonoToWav(samples, sampleRate);
  }
}
