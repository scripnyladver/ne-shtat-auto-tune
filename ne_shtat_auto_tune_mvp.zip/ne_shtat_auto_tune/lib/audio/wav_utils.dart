import 'dart:typed_data';

class WavUtils {
  static Uint8List pcm16MonoToWav(List<int> samples, int sampleRate) {
    final dataBytes = samples.length * 2;
    final bytes = ByteData(44 + dataBytes);
    void ascii(int offset, String value) {
      for (var i = 0; i < value.length; i++) {
        bytes.setUint8(offset + i, value.codeUnitAt(i));
      }
    }
    ascii(0, 'RIFF');
    bytes.setUint32(4, 36 + dataBytes, Endian.little);
    ascii(8, 'WAVE');
    ascii(12, 'fmt ');
    bytes.setUint32(16, 16, Endian.little);
    bytes.setUint16(20, 1, Endian.little);
    bytes.setUint16(22, 1, Endian.little);
    bytes.setUint32(24, sampleRate, Endian.little);
    bytes.setUint32(28, sampleRate * 2, Endian.little);
    bytes.setUint16(32, 2, Endian.little);
    bytes.setUint16(34, 16, Endian.little);
    ascii(36, 'data');
    bytes.setUint32(40, dataBytes, Endian.little);
    for (var i = 0; i < samples.length; i++) {
      bytes.setInt16(44 + i * 2, samples[i].clamp(-32768, 32767).toInt(), Endian.little);
    }
    return bytes.buffer.asUint8List();
  }

  static ({int sampleRate, List<int> samples}) parsePcm16Mono(Uint8List bytes) {
    if (bytes.length < 44 || String.fromCharCodes(bytes.sublist(0, 4)) != 'RIFF') {
      throw FormatException('Unsupported WAV file. Expected RIFF/WAVE.');
    }
    final data = ByteData.sublistView(bytes);
    final sampleRate = data.getUint32(24, Endian.little);
    final channels = data.getUint16(22, Endian.little);
    final bits = data.getUint16(34, Endian.little);
    if (channels != 1 || bits != 16) {
      throw FormatException('Expected mono 16-bit PCM WAV.');
    }
    var offset = 12;
    var dataOffset = -1;
    var dataLength = 0;
    while (offset + 8 <= bytes.length) {
      final id = String.fromCharCodes(bytes.sublist(offset, offset + 4));
      final size = data.getUint32(offset + 4, Endian.little);
      if (id == 'data') {
        dataOffset = offset + 8;
        dataLength = size;
        break;
      }
      offset += 8 + size + (size.isOdd ? 1 : 0);
    }
    if (dataOffset < 0) throw FormatException('WAV data chunk not found.');
    final count = dataLength ~/ 2;
    final samples = List<int>.generate(count, (i) => data.getInt16(dataOffset + i * 2, Endian.little));
    return (sampleRate: sampleRate, samples: samples);
  }
}
