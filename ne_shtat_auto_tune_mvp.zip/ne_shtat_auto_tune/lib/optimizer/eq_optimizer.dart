import '../models/eq_filter.dart';

/// Conservative starter optimizer. Input is a relative 1/3-octave spectrum in dB.
/// This is not a substitute for validating the acoustic measurement chain.
class EqOptimizer {
  static const List<double> centersHz = [
    31.5, 40, 50, 63, 80, 100, 125, 160, 200, 250, 315, 400,
    500, 630, 800, 1000, 1250, 1600, 2000, 2500, 3150, 4000,
    5000, 6300, 8000, 10000, 12500, 16000,
  ];

  /// Creates conservative cuts/boosts from a relative measured spectrum.
  /// [targetDb] is the desired target at each center frequency. If omitted,
  /// a flat relative target is used. Deep narrow nulls must not be boosted.
  List<EqFilter> calculate(List<double> measuredDb, {List<double>? targetDb}) {
    if (measuredDb.length != centersHz.length) {
      throw ArgumentError('Expected ${centersHz.length} spectrum bands.');
    }
    final target = targetDb ?? List<double>.filled(centersHz.length, 0);
    if (target.length != measuredDb.length) {
      throw ArgumentError('Target and measured spectrum lengths differ.');
    }

    // Use a broad median-like baseline to avoid chasing individual room modes.
    final filters = <EqFilter>[];
    for (var i = 1; i < measuredDb.length - 1; i++) {
      final localBaseline = (measuredDb[i - 1] + measuredDb[i] + measuredDb[i + 1]) / 3;
      final error = target[i] - localBaseline;
      // Positive boosts are limited aggressively; deep cancellations are not fixed.
      final gain = error.clamp(-6.0, 2.0).toDouble();
      if (gain.abs() < 1.5) continue;
      if (gain > 0 && measuredDb[i] < localBaseline - 4) continue;
      filters.add(EqFilter(
        frequencyHz: centersHz[i],
        gainDb: gain,
        q: 1.0,
      ));
    }
    filters.sort((a, b) => a.gainDb.abs().compareTo(b.gainDb.abs()));
    return filters.reversed.take(8).toList()
      ..sort((a, b) => a.frequencyHz.compareTo(b.frequencyHz));
  }
}
