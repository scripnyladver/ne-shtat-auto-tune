import 'dart:math' as math;

/// Lightweight 1/3-octave RMS analyzer for PCM16 WAV recordings.
/// It estimates relative band energy, not calibrated SPL or a lab-grade transfer function.
class SpectrumAnalyzer {
  static const centersHz = <double>[
    31.5, 40, 50, 63, 80, 100, 125, 160, 200, 250, 315, 400,
    500, 630, 800, 1000, 1250, 1600, 2000, 2500, 3150, 4000,
    5000, 6300, 8000, 10000, 12500, 16000,
  ];

  List<double> analyzePcm16(List<int> samples, int sampleRate) {
    if (samples.isEmpty) return List<double>.filled(centersHz.length, -90);
    final nyquist = sampleRate / 2.0;
    final results = <double>[];
    for (final center in centersHz) {
      final low = center / math.pow(2, 1 / 6);
      final high = center * math.pow(2, 1 / 6);
      if (high >= nyquist || low < 10) {
        results.add(-90);
        continue;
      }
      // Goertzel energy integrated over logarithmically spaced points in each band.
      var energy = 0.0;
      var count = 0;
      for (var p = 0; p < 7; p++) {
        final fraction = p / 6.0;
        final frequency = low * math.pow(high / low, fraction);
        energy += _goertzelPower(samples, sampleRate, frequency);
        count++;
      }
      final mean = energy / math.max(1, count);
      results.add(10 * math.log(math.max(mean, 1e-18)) / math.ln10);
    }
    final valid = results.where((v) => v > -80 && v.isFinite).toList();
    final reference = valid.isEmpty ? 0.0 : valid.reduce((a, b) => a + b) / valid.length;
    return results.map((v) => v <= -80 ? -90 : v - reference).toList();
  }

  double _goertzelPower(List<int> samples, int sampleRate, double frequency) {
    final omega = 2 * math.pi * frequency / sampleRate;
    final coeff = 2 * math.cos(omega);
    var s1 = 0.0;
    var s2 = 0.0;
    final length = samples.length;
    // A Hann window reduces leakage; step over full recording for this prototype.
    for (var i = 0; i < length; i++) {
      final window = length <= 1 ? 1.0 : 0.5 - 0.5 * math.cos(2 * math.pi * i / (length - 1));
      final x = (samples[i] / 32768.0) * window;
      final s0 = x + coeff * s1 - s2;
      s2 = s1;
      s1 = s0;
    }
    final power = s1 * s1 + s2 * s2 - coeff * s1 * s2;
    return math.max(0.0, power) / (length * length);
  }
}
