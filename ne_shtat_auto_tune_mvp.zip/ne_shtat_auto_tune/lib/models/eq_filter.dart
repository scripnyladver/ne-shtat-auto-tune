class EqFilter {
  const EqFilter({
    required this.frequencyHz,
    required this.gainDb,
    required this.q,
    this.enabled = true,
  });

  final double frequencyHz;
  final double gainDb;
  final double q;
  final bool enabled;

  Map<String, dynamic> toJson() => {
        'type': 'peaking',
        'frequencyHz': frequencyHz,
        'gainDb': gainDb,
        'q': q,
        'enabled': enabled,
      };
}
