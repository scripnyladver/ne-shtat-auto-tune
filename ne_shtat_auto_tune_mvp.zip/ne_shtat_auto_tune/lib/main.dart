import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:audioplayers/audioplayers.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:record/record.dart';

import 'audio/test_signal.dart';
import 'audio/wav_utils.dart';
import 'measurement/spectrum_analyzer.dart';
import 'models/eq_filter.dart';
import 'optimizer/eq_optimizer.dart';

void main() => runApp(const NeShtatApp());

const orange = Color(0xFFFF9F1C);
const bg = Color(0xFF101114);
const panel = Color(0xFF1B1D22);

class NeShtatApp extends StatelessWidget {
  const NeShtatApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'НЕ ШТАТ Auto Tune',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          brightness: Brightness.dark,
          scaffoldBackgroundColor: bg,
          colorScheme: ColorScheme.fromSeed(seedColor: orange, brightness: Brightness.dark),
          useMaterial3: true,
          cardColor: panel,
        ),
        home: const HomePage(),
      );
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final _recorder = AudioRecorder();
  final _player = AudioPlayer();
  final _analyzer = SpectrumAnalyzer();
  final _optimizer = EqOptimizer();
  bool _busy = false;
  String _status = 'Готово к измерению';
  List<double> _spectrum = [];
  List<EqFilter> _filters = [];
  String? _lastWavPath;
  static const _bands = SpectrumAnalyzer.centersHz;

  @override
  void dispose() {
    _recorder.dispose();
    _player.dispose();
    super.dispose();
  }

  Future<void> _measure() async {
    if (_busy) return;
    setState(() { _busy = true; _status = 'Проверка микрофона…'; });
    try {
      final permission = await Permission.microphone.request();
      if (!permission.isGranted) throw Exception('Нужно разрешить доступ к микрофону.');
      final dir = await getTemporaryDirectory();
      final sweepPath = '${dir.path}/ne_shtat_sweep.wav';
      final recPath = '${dir.path}/ne_shtat_recording.wav';
      final sweep = TestSignal.logarithmicSweepWav();
      await File(sweepPath).writeAsBytes(sweep, flush: true);
      if (!await _recorder.hasPermission()) throw Exception('Нет доступа к микрофону.');
      setState(() => _status = 'Запись и воспроизведение тестового сигнала…');
      await _recorder.start(
        const RecordConfig(encoder: AudioEncoder.wav, sampleRate: 48000, numChannels: 1),
        path: recPath,
      );
      await Future<void>.delayed(const Duration(milliseconds: 350));
      await _player.play(DeviceFileSource(sweepPath));
      await Future<void>.delayed(const Duration(seconds: 9));
      final stoppedPath = await _recorder.stop();
      if (stoppedPath == null || !await File(stoppedPath).exists()) {
        throw Exception('Запись не сохранилась. Проверьте разрешения и аудиоустройство.');
      }
      final bytes = await File(stoppedPath).readAsBytes();
      final parsed = WavUtils.parsePcm16Mono(Uint8List.fromList(bytes));
      final spectrum = _analyzer.analyzePcm16(parsed.samples, parsed.sampleRate);
      final filters = _optimizer.calculate(spectrum);
      setState(() {
        _spectrum = spectrum;
        _filters = filters;
        _lastWavPath = stoppedPath;
        _status = 'Измерение обработано · требуется проверка качества';
      });
    } catch (e) {
      setState(() => _status = 'Не удалось измерить: $e');
    } finally {
      if (await _recorder.isRecording()) await _recorder.stop();
      setState(() => _busy = false);
    }
  }

  Future<void> _export() async {
    final payload = {
      'schemaVersion': 1,
      'projectName': 'NE SHTAT Auto Tune measurement',
      'measurement': {'microphone': 'android_or_ios_builtin', 'calibrated': false, 'method': 'prototype_sweep_spectrum'},
      'eqFilters': _filters.map((f) => f.toJson()).toList(),
      'warning': 'Experimental relative spectrum. Validate with repeat measurements before applying to a DSP.',
    };
    final dir = await getApplicationDocumentsDirectory();
    final file = File('${dir.path}/ne_shtat_eq_profile.json');
    await file.writeAsString(const JsonEncoder.withIndent('  ').convert(payload));
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Профиль сохранён: ${file.path}')));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('НЕ ШТАТ', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 2)),
          Text('AUTO TUNE · EXPERIMENTAL MVP', style: TextStyle(fontSize: 10, color: Colors.white54, letterSpacing: 1.3)),
        ]),
        actions: [IconButton(onPressed: _export, icon: const Icon(Icons.file_download_outlined), tooltip: 'Экспорт JSON')],
      ),
      body: SafeArea(
        child: ListView(padding: const EdgeInsets.all(16), children: [
          Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(22), border: Border.all(color: Colors.white10)),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('АВТОМАТИЧЕСКАЯ КАЛИБРОВКА', style: TextStyle(color: orange, fontSize: 11, fontWeight: FontWeight.bold, letterSpacing: 1.4)),
              const SizedBox(height: 8),
              const Text('Измерь. Проанализируй. Настрой.', style: TextStyle(fontSize: 23, fontWeight: FontWeight.w800)),
              const SizedBox(height: 8),
              const Text('Поставьте автомобиль на стоянку, заглушите двигатель и разместите телефон в точке прослушивания. Начните с небольшой громкости.', style: TextStyle(color: Colors.white60, height: 1.45)),
              const SizedBox(height: 16),
              SizedBox(width: double.infinity, height: 54, child: FilledButton.icon(
                onPressed: _busy ? null : _measure,
                icon: _busy ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.graphic_eq),
                label: Text(_busy ? 'ИЗМЕРЕНИЕ…' : 'НАЧАТЬ ИЗМЕРЕНИЕ', style: const TextStyle(fontWeight: FontWeight.w800, letterSpacing: 1)),
              )),
              const SizedBox(height: 10),
              Text(_status, style: const TextStyle(fontSize: 12, color: Colors.white54)),
            ]),
          ),
          const SizedBox(height: 16),
          _sectionHeader('ЧАСТОТНАЯ ХАРАКТЕРИСТИКА', 'ОТНОСИТЕЛЬНАЯ'),
          const SizedBox(height: 10),
          Container(
            height: 250,
            padding: const EdgeInsets.fromLTRB(8, 18, 18, 8),
            decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(18)),
            child: _spectrum.isEmpty
                ? const Center(child: Text('Здесь появится график после измерения', style: TextStyle(color: Colors.white38)))
                : LineChart(LineChartData(
                    minY: -18, maxY: 12,
                    gridData: const FlGridData(show: true, drawVerticalLine: false),
                    borderData: FlBorderData(show: false),
                    titlesData: FlTitlesData(
                      topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                      rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                      leftTitles: const AxisTitles(sideTitles: SideTitles(showTitles: true, reservedSize: 34)),
                      bottomTitles: AxisTitles(sideTitles: SideTitles(showTitles: true, reservedSize: 28, getTitlesWidget: (value, meta) {
                        final i = value.round();
                        if (i < 0 || i >= _bands.length || i % 5 != 0) return const SizedBox.shrink();
                        final f = _bands[i];
                        return Padding(padding: const EdgeInsets.only(top: 8), child: Text(f >= 1000 ? '${(f / 1000).toStringAsFixed(f % 1000 == 0 ? 0 : 1)}k' : '${f.round()}', style: const TextStyle(fontSize: 9, color: Colors.white54)));
                      })),
                    ),
                    lineBarsData: [LineChartBarData(
                      spots: List.generate(_spectrum.length, (i) => FlSpot(i.toDouble(), _spectrum[i].clamp(-18, 12).toDouble())),
                      isCurved: true, color: orange, barWidth: 2.5, dotData: const FlDotData(show: false),
                      belowBarData: BarAreaData(show: true, color: orange.withOpacity(0.08)),
                    )],
                  )),
          ),
          const SizedBox(height: 8),
          const Text('Прототип анализирует относительную энергию частотных полос. Это ещё не калиброванная АЧХ салона и не лабораторное измерение передаточной функции.', style: TextStyle(color: Colors.white38, fontSize: 11, height: 1.4)),
          const SizedBox(height: 20),
          _sectionHeader('РАСЧЁТ PEQ', '${_filters.length} ФИЛЬТРОВ'),
          const SizedBox(height: 10),
          if (_filters.isEmpty)
            Container(padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(16)), child: const Text('Сначала выполните измерение. Расчёт фильтров будет доступен при наличии данных.', style: TextStyle(color: Colors.white54)))
          else ...[
            ..._filters.map((f) => Container(
              margin: const EdgeInsets.only(bottom: 8), padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(14)),
              child: Row(children: [
                Container(width: 42, height: 42, decoration: BoxDecoration(color: orange.withOpacity(0.13), borderRadius: BorderRadius.circular(12)), child: const Icon(Icons.tune, color: orange)),
                const SizedBox(width: 12),
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('${f.frequencyHz.toStringAsFixed(0)} Hz', style: const TextStyle(fontWeight: FontWeight.bold)), Text('PEAKING · Q ${f.q.toStringAsFixed(1)}', style: const TextStyle(fontSize: 10, color: Colors.white38))])),
                Text('${f.gainDb > 0 ? '+' : ''}${f.gainDb.toStringAsFixed(1)} dB', style: TextStyle(color: f.gainDb < 0 ? const Color(0xFF55C5A1) : orange, fontWeight: FontWeight.w800)),
              ]),
            )),
            SizedBox(width: double.infinity, child: OutlinedButton.icon(onPressed: _export, icon: const Icon(Icons.save_alt), label: const Text('ЭКСПОРТИРОВАТЬ ПРОФИЛЬ DSP'))),
          ],
          const SizedBox(height: 18),
          Container(padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: const Color(0xFF292219), borderRadius: BorderRadius.circular(14), border: Border.all(color: orange.withOpacity(0.25))), child: const Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Icon(Icons.info_outline, color: orange), SizedBox(width: 10), Expanded(child: Text('Не применяйте рассчитанные фильтры вслепую. Встроенный микрофон может иметь собственную АЧХ и обработку. Перед использованием в DSP проверьте результат повторным измерением; не проводите тестирование во время движения.', style: TextStyle(fontSize: 12, height: 1.45, color: Colors.white70))),
          ])),
        ]),
      ),
    );
  }

  Widget _sectionHeader(String title, String trailing) => Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
    Text(title, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w800, letterSpacing: 1.1)),
    Text(trailing, style: const TextStyle(fontSize: 10, color: orange, fontWeight: FontWeight.bold)),
  ]);
}
