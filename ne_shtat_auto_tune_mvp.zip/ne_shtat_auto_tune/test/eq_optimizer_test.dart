import 'package:flutter_test/flutter_test.dart';
import 'package:ne_shtat_auto_tune/optimizer/eq_optimizer.dart';

void main() {
  test('optimizer accepts expected number of bands', () {
    final optimizer = EqOptimizer();
    final spectrum = List<double>.filled(EqOptimizer.centersHz.length, 0);
    expect(() => optimizer.calculate(spectrum), returnsNormally);
  });

  test('optimizer rejects invalid spectrum length', () {
    final optimizer = EqOptimizer();
    expect(() => optimizer.calculate([0, 1]), throwsArgumentError);
  });
}
