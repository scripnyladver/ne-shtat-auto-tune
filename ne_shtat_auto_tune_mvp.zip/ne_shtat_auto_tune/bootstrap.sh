#!/usr/bin/env bash
set -euo pipefail

if ! command -v flutter >/dev/null 2>&1; then
  echo "Flutter SDK is required. Install Flutter stable first: https://docs.flutter.dev/get-started/install"
  exit 1
fi

flutter create --platforms=android,ios .
python3 - <<'PY'
from pathlib import Path
android = Path('android/app/src/main/AndroidManifest.xml')
if android.exists():
    s = android.read_text()
    permission = '    <uses-permission android:name="android.permission.RECORD_AUDIO" />\n'
    if 'android.permission.RECORD_AUDIO' not in s:
        s = s.replace('<manifest xmlns:android="http://schemas.android.com/apk/res/android">', '<manifest xmlns:android="http://schemas.android.com/apk/res/android">\n' + permission.rstrip())
        android.write_text(s)
plist = Path('ios/Runner/Info.plist')
if plist.exists():
    s = plist.read_text()
    key = '<key>NSMicrophoneUsageDescription</key>\n\t<string>Microphone access is used to measure your car audio system.</string>\n'
    if 'NSMicrophoneUsageDescription' not in s:
        s = s.replace('</dict>', '\t' + key + '</dict>')
        plist.write_text(s)
PY
flutter pub get

echo "Project bootstrapped. Run: flutter run"
