# НЕ ШТАТ Auto Tune — cross-platform MVP starter

Flutter starter project for Android and iOS. Includes a dark branded UI, test sweep WAV generation, microphone recording, a prototype 1/3-octave relative spectrum estimator, conservative PEQ suggestion logic, and JSON profile export.

## Important technical status

This is an **experimental MVP starter**, not a validated acoustic measurement product. The current spectrum estimator uses Goertzel band-energy estimates over the captured recording. It does not yet perform a calibrated sweep deconvolution / transfer-function estimate and therefore its PEQ suggestions must not be treated as reliable DSP settings. The app UI explicitly warns about this.

Before any real deployment, implement and validate:
- sweep synchronization and deconvolution against a known reference signal;
- device-specific audio input/output behavior and processing detection;
- repeatability tests across multiple iOS and Android devices;
- calibrated external microphone support;
- DSP-specific export adapters only where protocols are documented/authorized;
- robust cancellation, audio session handling, and background interruption recovery.

## Run

Install Flutter SDK (stable), then from this directory run the bootstrap script. It generates native Android/iOS runners, adds microphone permission strings, and fetches dependencies:

```bash
./bootstrap.sh
flutter run
```

To build Android:

```bash
flutter build apk --debug
```

To build iOS, use macOS with Xcode configured:

```bash
flutter build ios --debug
```

## Platform permissions

Android: add `android.permission.RECORD_AUDIO` to `android/app/src/main/AndroidManifest.xml`.

iOS: add `NSMicrophoneUsageDescription` to `ios/Runner/Info.plist`, for example: `Microphone access is used to measure your car audio system.`

The `permission_handler` plugin may require platform-specific setup depending on the versions of Flutter and the plugin.

## Usage

1. Park the vehicle safely and keep the engine off where practical.
2. Set a low, safe playback volume.
3. Put the phone in a stable position near the listening point.
4. Tap **НАЧАТЬ ИЗМЕРЕНИЕ**.
5. Review the relative spectrum and export the JSON profile for inspection.

Do not use the generated filter values directly in a DSP until the measurement engine has been calibrated and validated.
