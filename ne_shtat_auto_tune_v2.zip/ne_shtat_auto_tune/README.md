# НЕ ШТАТ Auto Tune V2

Flutter Android/iOS prototype for car-audio measurement workflow.

## Included
- Per-speaker and DSP-channel selection (manual selection; no direct DSP connection yet).
- Test signals: logarithmic sweep, pink noise, white noise, experimental high-frequency-limited pink noise, and sine tone.
- Record from the phone microphone while playing a test signal.
- Relative 1/3-octave spectrum chart and basic local peak/dip flags.
- Conservative peak-cut hints (not a validated PEQ optimizer).
- Distance-based delay calculator for up to 10 DSP channels.
- JSON export with measurement, findings, distances and calculated delays.

## Important measurement limits
This is a development prototype, not a calibrated acoustic measurement system. The built-in phone microphone may have frequency-response correction, automatic gain control, noise suppression and a non-flat response. The displayed curve is relative band energy, not calibrated SPL and not a reliable transfer function. The sweep is not deconvolved against a loopback reference, and the app does not control Hellion/STORM DSP hardware. Delay calculations based on distance are only starting values. Use a calibrated measurement microphone and repeatable setup before applying changes to a real DSP.

The experimental "band-limited pink noise" is a listening/test variant, not a precision crossover filter. Use low playback volume, never test while driving, and avoid long high-level sine tones especially through tweeters.

## Build
Run `./bootstrap.sh`, then `flutter build apk --release`.
