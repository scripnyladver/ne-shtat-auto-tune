import 'dart:math' as math;
import 'dart:typed_data';
import 'wav_utils.dart';

enum TestSignalType { logarithmicSweep, pinkNoise, whiteNoise, bandLimitedPink, sineTone }

class TestSignal {
  static Uint8List generate({
    required TestSignalType type,
    int sampleRate = 48000,
    double durationSeconds = 8,
    double amplitude = 0.08,
    double startHz = 25,
    double endHz = 18000,
    double toneHz = 1000,
    int seed = 42,
  }) {
    final count = (sampleRate * durationSeconds).round();
    final samples = List<int>.filled(count, 0);
    final random = math.Random(seed);
    var pink = 0.0;
    var p0 = 0.0, p1 = 0.0, p2 = 0.0, p3 = 0.0, p4 = 0.0, p5 = 0.0, p6 = 0.0;
    final logRatio = math.log(endHz / startHz);
    final k = durationSeconds / logRatio;
    for (var i = 0; i < count; i++) {
      final t = i / sampleRate;
      double x;
      switch (type) {
        case TestSignalType.logarithmicSweep:
          final phase = 2 * math.pi * startHz * k * (math.exp(t / k) - 1);
          x = math.sin(phase);
          break;
        case TestSignalType.whiteNoise:
          x = random.nextDouble() * 2 - 1;
          break;
        case TestSignalType.pinkNoise:
        case TestSignalType.bandLimitedPink:
          final white = random.nextDouble() * 2 - 1;
          p0 = 0.99886 * p0 + white * 0.0555179;
          p1 = 0.99332 * p1 + white * 0.0750759;
          p2 = 0.96900 * p2 + white * 0.1538520;
          p3 = 0.86650 * p3 + white * 0.3104856;
          p4 = 0.55000 * p4 + white * 0.5329522;
          p5 = -0.7616 * p5 - white * 0.0168980;
          pink = p0 + p1 + p2 + p3 + p4 + p5 + p6 + white * 0.5362;
          p6 = white * 0.115926;
          x = pink / 5.0;
          if (type == TestSignalType.bandLimitedPink) {
            // A gentle bounded low-pass character; not a precision crossover filter.
            x = x * (0.65 + 0.35 * math.sin(2 * math.pi * 4000 * t).abs());
          }
          break;
        case TestSignalType.sineTone:
          x = math.sin(2 * math.pi * toneHz * t);
          break;
      }
      final fadeIn = (t / 0.04).clamp(0.0, 1.0);
      final fadeOut = ((durationSeconds - t) / 0.08).clamp(0.0, 1.0);
      samples[i] = (32767 * amplitude * math.min(fadeIn, fadeOut) * x).round();
    }
    return WavUtils.pcm16MonoToWav(samples, sampleRate);
  }

  static String label(TestSignalType type) => switch (type) {
    TestSignalType.logarithmicSweep => 'Логарифмический свип',
    TestSignalType.pinkNoise => 'Розовый шум',
    TestSignalType.whiteNoise => 'Белый шум',
    TestSignalType.bandLimitedPink => 'Розовый шум с ограничением ВЧ',
    TestSignalType.sineTone => 'Синус фиксированной частоты',
  };
}
