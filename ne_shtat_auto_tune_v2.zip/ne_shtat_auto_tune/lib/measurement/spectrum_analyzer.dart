import 'dart:math' as math;

/// Fast relative 1/3-octave spectrum estimator. This is not calibrated SPL or a true transfer-function measurement.
class SpectrumAnalyzer {
  static const centersHz = <double>[
    31.5, 40, 50, 63, 80, 100, 125, 160, 200, 250, 315, 400,
    500, 630, 800, 1000, 1250, 1600, 2000, 2500, 3150, 4000,
    5000, 6300, 8000, 10000, 12500, 16000,
  ];

  List<double> analyzePcm16(List<int> samples, int sampleRate) {
    if (samples.isEmpty) return List<double>.filled(centersHz.length, -90.0);
    final usable = samples.length >= 16384 ? samples.length : samples.length;
    final segmentLength = math.min(16384, usable).toInt();
    final hop = math.max(segmentLength, usable ~/ 4).toInt();
    final starts = <int>[];
    for (var s = 0; s + segmentLength <= usable; s += hop) { starts.add(s); }
    if (starts.isEmpty) starts.add(0);
    final results = <double>[];
    final nyquist = sampleRate / 2.0;
    for (final center in centersHz) {
      final low = center / math.pow(2, 1 / 6);
      final high = center * math.pow(2, 1 / 6);
      if (high >= nyquist || low < 10) { results.add(-90.0); continue; }
      var energy = 0.0;
      var count = 0;
      for (var p = 0; p < 7; p++) {
        final frequency = low * math.pow(high / low, p / 6.0);
        for (final start in starts) {
          energy += _goertzelPower(samples, start, segmentLength, sampleRate, frequency);
          count++;
        }
      }
      results.add(10 * math.log(math.max(energy / math.max(1, count), 1e-18)) / math.ln10);
    }
    final valid = results.where((v) => v > -80 && v.isFinite).toList();
    final reference = valid.isEmpty ? 0.0 : valid.reduce((a, b) => a + b) / valid.length;
    return results.map((v) => v <= -80 ? -90.0 : v - reference).toList();
  }

  double _goertzelPower(List<int> samples, int start, int length, int sampleRate, double frequency) {
    final omega = 2 * math.pi * frequency / sampleRate;
    final coeff = 2 * math.cos(omega);
    var s1 = 0.0, s2 = 0.0;
    for (var j = 0; j < length; j++) {
      final window = length <= 1 ? 1.0 : 0.5 - 0.5 * math.cos(2 * math.pi * j / (length - 1));
      final x = (samples[start + j] / 32768.0) * window;
      final s0 = x + coeff * s1 - s2;
      s2 = s1;
      s1 = s0;
    }
    final power = s1 * s1 + s2 * s2 - coeff * s1 * s2;
    return math.max(0.0, power) / (length * length);
  }
}
