import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:audioplayers/audioplayers.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:record/record.dart';

import 'audio/test_signal.dart';
import 'audio/wav_utils.dart';
import 'measurement/spectrum_analyzer.dart';

void main() => runApp(const NeShtatApp());
const orange = Color(0xFFFF9F1C);
const bg = Color(0xFF101114);
const panel = Color(0xFF1B1D22);
const green = Color(0xFF54D6A1);

class NeShtatApp extends StatelessWidget {
  const NeShtatApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'НЕ ШТАТ Auto Tune', debugShowCheckedModeBanner: false,
    theme: ThemeData(brightness: Brightness.dark, scaffoldBackgroundColor: bg,
      colorScheme: ColorScheme.fromSeed(seedColor: orange, brightness: Brightness.dark), useMaterial3: true),
    home: const MainScreen(),
  );
}

class MainScreen extends StatefulWidget {
  const MainScreen({super.key});
  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  final _recorder = AudioRecorder();
  final _player = AudioPlayer();
  final _analyzer = SpectrumAnalyzer();
  int _tab = 0;
  bool _busy = false;
  String _status = 'Готово. Машина должна стоять на месте.';
  String _speaker = 'Фронт левый мидбас';
  String _channel = 'CH 1';
  TestSignalType _signal = TestSignalType.pinkNoise;
  double _duration = 8;
  double _toneHz = 1000;
  List<double> _spectrum = [];
  List<double> _beforeSpectrum = [];
  List<double> _afterSpectrum = [];
  List<Map<String, dynamic>> _findings = [];
  DateTime? _lastMeasurement;
  final Map<String, double> _distances = {'CH 1': 79, 'CH 2': 119, 'CH 3': 79, 'CH 4': 110, 'CH 5': 100, 'CH 6': 100, 'CH 7': 100, 'CH 8': 100};

  @override
  void dispose() { _recorder.dispose(); _player.dispose(); super.dispose(); }

  Future<void> _runTest() async {
    if (_busy) return;
    setState(() { _busy = true; _status = 'Запрашиваю доступ к микрофону…'; });
    try {
      final permission = await Permission.microphone.request();
      if (!permission.isGranted || !await _recorder.hasPermission()) throw Exception('Разреши приложению доступ к микрофону в настройках Android.');
      final dir = await getTemporaryDirectory();
      final signalPath = '${dir.path}/ne_shtat_test.wav';
      final recordingPath = '${dir.path}/ne_shtat_recording.wav';
      final bytes = TestSignal.generate(type: _signal, durationSeconds: _duration, toneHz: _toneHz, amplitude: 0.055);
      await File(signalPath).writeAsBytes(bytes, flush: true);
      setState(() => _status = 'Запись микрофона и воспроизведение: ${TestSignal.label(_signal)}…');
      await _recorder.start(const RecordConfig(encoder: AudioEncoder.wav, sampleRate: 48000, numChannels: 1), path: recordingPath);
      await Future<void>.delayed(const Duration(milliseconds: 350));
      await _player.play(DeviceFileSource(signalPath));
      await Future<void>.delayed(Duration(milliseconds: (_duration * 1000).round() + 450));
      final saved = await _recorder.stop();
      if (saved == null || !await File(saved).exists()) throw Exception('Не удалось сохранить запись микрофона.');
      final wav = WavUtils.parsePcm16Mono(Uint8List.fromList(await File(saved).readAsBytes()));
      final result = _analyzer.analyzePcm16(wav.samples, wav.sampleRate);
      final findings = _detectIssues(result);
      setState(() {
        _beforeSpectrum = List<double>.from(_spectrum);
        _spectrum = result;
        _findings = findings;
        _lastMeasurement = DateTime.now();
        _status = 'Измерение сохранено локально · ${TestSignal.label(_signal)} · $_channel';
      });
    } catch (e) {
      setState(() => _status = 'Ошибка: $e');
    } finally {
      try { if (await _recorder.isRecording()) await _recorder.stop(); } catch (_) {}
      if (mounted) setState(() => _busy = false);
    }
  }

  List<Map<String, dynamic>> _detectIssues(List<double> data) {
    final bands = SpectrumAnalyzer.centersHz;
    final rows = <Map<String, dynamic>>[];
    for (var i = 1; i < data.length - 1; i++) {
      if (data[i] > 3.5 && data[i] >= data[i - 1] && data[i] >= data[i + 1]) {
        rows.add({'frequencyHz': bands[i], 'levelDb': data[i], 'type': 'peak', 'suggestionDb': -((data[i] - 1.5).clamp(0.0, 4.0))});
      } else if (data[i] < -5.0 && data[i] <= data[i - 1] && data[i] <= data[i + 1]) {
        rows.add({'frequencyHz': bands[i], 'levelDb': data[i], 'type': 'dip', 'suggestionDb': 0.0});
      }
    }
    rows.sort((a, b) => (b['levelDb'] as double).abs().compareTo((a['levelDb'] as double).abs()));
    return rows.take(8).toList();
  }

  double get _referenceDistance => _distances.values.reduce((a, b) => a < b ? a : b);
  double _delayMs(double cm) => (cm - _referenceDistance) / 34.3;

  Future<void> _exportProfile() async {
    final payload = {
      'schemaVersion': 2,
      'app': 'НЕ ШТАТ Auto Tune',
      'createdAt': DateTime.now().toIso8601String(),
      'selectedSpeaker': _speaker,
      'dspChannel': _channel,
      'lastTestSignal': TestSignal.label(_signal),
      'measurement': {'date': _lastMeasurement?.toIso8601String(), 'bandsHz': SpectrumAnalyzer.centersHz, 'relativeSpectrumDb': _spectrum, 'microphone': 'built-in, uncalibrated', 'splCalibrated': false},
      'findings': _findings,
      'delayCalculator': _distances.map((k, v) => MapEntry(k, {'distanceCm': v, 'delayMs': _delayMs(v)})),
      'limitations': ['This app does not control the DSP directly.', 'Relative spectrum is not calibrated SPL or a true transfer function.', 'Do not apply suggested EQ blindly; verify with repeat measurements and proper measurement microphone.'],
    };
    final dir = await getApplicationDocumentsDirectory();
    final file = File('${dir.path}/ne_shtat_profile_${DateTime.now().millisecondsSinceEpoch}.json');
    await file.writeAsString(const JsonEncoder.withIndent('  ').convert(payload));
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('JSON-профиль сохранён: ${file.path}')));
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text('НЕ ШТАТ', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 2)),
      Text('AUTO TUNE · V2 WORKBENCH', style: TextStyle(fontSize: 10, color: Colors.white54, letterSpacing: 1.2)),
    ]), actions: [IconButton(onPressed: _exportProfile, icon: const Icon(Icons.file_download_outlined), tooltip: 'Экспорт профиля')]),
    body: SafeArea(child: IndexedStack(index: _tab, children: [_measurementPage(), _analysisPage(), _delayPage()])),
    bottomNavigationBar: NavigationBar(selectedIndex: _tab, onDestinationSelected: (v) => setState(() => _tab = v), destinations: const [
      NavigationDestination(icon: Icon(Icons.graphic_eq), label: 'Тесты'),
      NavigationDestination(icon: Icon(Icons.show_chart), label: 'Анализ'),
      NavigationDestination(icon: Icon(Icons.timer_outlined), label: 'Задержки'),
    ]),
  );

  Widget _measurementPage() => ListView(padding: const EdgeInsets.all(16), children: [
    _hero(), const SizedBox(height: 14),
    _section('КОНФИГУРАЦИЯ ТЕСТА', '1 · ВЫБОР'),
    _card(Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('Какой динамик измеряем?', style: TextStyle(color: Colors.white60, fontSize: 12)), const SizedBox(height: 6),
      DropdownButtonFormField<String>(value: _speaker, isExpanded: true, items: const ['Фронт левый мидбас','Фронт правый мидбас','Левый твитер','Правый твитер','Левый СЧ','Правый СЧ','Сабвуфер','Вся система'].map((s) => DropdownMenuItem(value: s, child: Text(s))).toList(), onChanged: (v) => setState(() => _speaker = v ?? _speaker)),
      const SizedBox(height: 12), const Text('Выход DSP', style: TextStyle(color: Colors.white60, fontSize: 12)), const SizedBox(height: 6),
      DropdownButtonFormField<String>(value: _channel, items: List.generate(10, (i) => 'CH ${i + 1}').map((s) => DropdownMenuItem(value: s, child: Text(s))).toList(), onChanged: (v) => setState(() => _channel = v ?? _channel)),
      const SizedBox(height: 12), const Text('Тестовый сигнал', style: TextStyle(color: Colors.white60, fontSize: 12)), const SizedBox(height: 6),
      DropdownButtonFormField<TestSignalType>(value: _signal, isExpanded: true, items: TestSignalType.values.map((s) => DropdownMenuItem(value: s, child: Text(TestSignal.label(s)))).toList(), onChanged: (v) => setState(() => _signal = v ?? _signal)),
      if (_signal == TestSignalType.sineTone) ...[
        const SizedBox(height: 10), Row(children: [const Text('Частота синуса'), const Spacer(), Text('${_toneHz.round()} Hz', style: const TextStyle(color: orange, fontWeight: FontWeight.bold))]),
        Slider(value: _toneHz, min: 20, max: 16000, divisions: 1598, onChanged: (v) => setState(() => _toneHz = v)),
      ],
      const SizedBox(height: 10), Row(children: [const Text('Длительность'), const Spacer(), Text('${_duration.round()} сек', style: const TextStyle(color: orange, fontWeight: FontWeight.bold))]),
      Slider(value: _duration, min: 4, max: 16, divisions: 6, onChanged: (v) => setState(() => _duration = v)),
      const SizedBox(height: 8), SizedBox(width: double.infinity, height: 52, child: FilledButton.icon(onPressed: _busy ? null : _runTest, icon: _busy ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.play_arrow), label: Text(_busy ? 'ИДЁТ ЗАПИСЬ…' : 'ЗАПИСАТЬ И АНАЛИЗИРОВАТЬ')),
      const SizedBox(height: 10), Text(_status, style: const TextStyle(color: Colors.white54, fontSize: 12)),
    ])),
    const SizedBox(height: 14), _section('БИБЛИОТЕКА СИГНАЛОВ', '5 ТИПОВ'),
    _signalInfo('Розовый шум', 'Для оценки тонального баланса по полосам. Не является калибровкой SPL.', Icons.graphic_eq),
    _signalInfo('Белый шум', 'Шум с равной мощностью на герц. Воспринимается ярче розового.', Icons.blur_on),
    _signalInfo('Розовый шум с ограничением ВЧ', 'Экспериментальный вариант для прослушивания; не точный измерительный фильтр.', Icons.tune),
    _signalInfo('Логарифмический свип', 'Плавный проход частот. Для корректной передаточной функции нужен синхронный анализ и учёт задержки.', Icons.multiline_chart),
    _signalInfo('Синус', 'Проверка отдельных частот на малой громкости. Долго не держать на твитерах.', Icons.waves),
    const SizedBox(height: 12), _warning('Перед тестом заглуши двигатель, поставь машину на стоянку и снизь громкость. Не запускай свип на высокой мощности: твитеры и слух не обязаны страдать ради науки.'),
  ]);

  Widget _hero() => Container(padding: const EdgeInsets.all(18), decoration: BoxDecoration(gradient: const LinearGradient(colors: [Color(0xFF29231A), panel], begin: Alignment.topLeft, end: Alignment.bottomRight), borderRadius: BorderRadius.circular(22), border: Border.all(color: orange.withOpacity(.28))), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    const Text('MEASURE · FIND · TUNE', style: TextStyle(color: orange, fontSize: 11, fontWeight: FontWeight.w900, letterSpacing: 1.8)),
    const SizedBox(height: 8), const Text('Измерительная мастерская', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
    const SizedBox(height: 8), const Text('Отдельный тест для выбранного динамика и канала DSP. Сохраняем спектр, отмечаем локальные пики и провалы, рассчитываем задержки по расстояниям.', style: TextStyle(color: Colors.white60, height: 1.45)),
    const SizedBox(height: 12), Row(children: [const Icon(Icons.circle, size: 8, color: green), const SizedBox(width: 7), Text(_lastMeasurement == null ? 'Нет измерений в этой сессии' : 'Последнее измерение: ${_lastMeasurement!.hour.toString().padLeft(2,'0')}:${_lastMeasurement!.minute.toString().padLeft(2,'0')}', style: const TextStyle(fontSize: 11, color: Colors.white70))]),
  ]));

  Widget _analysisPage() => ListView(padding: const EdgeInsets.all(16), children: [
    _section('АНАЛИЗ АЧХ', _spectrum.isEmpty ? 'НЕТ ДАННЫХ' : '$_speaker · $_channel'),
    const SizedBox(height: 10), _card(Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('Относительный спектр 1/3 октавы', style: TextStyle(fontWeight: FontWeight.bold)), const SizedBox(height: 5),
      const Text('dB относительно среднего уровня полос. Не абсолютный SPL.', style: TextStyle(color: Colors.white45, fontSize: 11)), const SizedBox(height: 14),
      SizedBox(height: 270, child: _spectrum.isEmpty ? const Center(child: Text('Выполни тест на вкладке «Тесты»', style: TextStyle(color: Colors.white38))) : LineChart(LineChartData(
        minY: -18, maxY: 12, gridData: const FlGridData(show: true, drawVerticalLine: false), borderData: FlBorderData(show: false),
        titlesData: FlTitlesData(topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)), rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)), leftTitles: const AxisTitles(sideTitles: SideTitles(showTitles: true, reservedSize: 32)), bottomTitles: AxisTitles(sideTitles: SideTitles(showTitles: true, reservedSize: 28, getTitlesWidget: (v, meta) { final i = v.round(); if (i < 0 || i >= SpectrumAnalyzer.centersHz.length || i % 5 != 0) return const SizedBox.shrink(); final f = SpectrumAnalyzer.centersHz[i]; return Padding(padding: const EdgeInsets.only(top: 7), child: Text(f >= 1000 ? '${(f/1000).toStringAsFixed(f%1000==0?0:1)}k' : '${f.round()}', style: const TextStyle(fontSize: 9, color: Colors.white54))); })),
        lineBarsData: [LineChartBarData(spots: List.generate(_spectrum.length, (i) => FlSpot(i.toDouble(), _spectrum[i].clamp(-18, 12).toDouble())), isCurved: true, color: orange, barWidth: 2.5, dotData: const FlDotData(show: false), belowBarData: BarAreaData(show: true, color: orange.withOpacity(.07)))],
      ))),
      const SizedBox(height: 8), if (_spectrum.isNotEmpty) Row(children: [Expanded(child: OutlinedButton.icon(onPressed: () => setState(() => _beforeSpectrum = List<double>.from(_spectrum)), icon: const Icon(Icons.bookmark_border), label: const Text('Зафиксировать «до»'))), const SizedBox(width: 8), Expanded(child: OutlinedButton.icon(onPressed: _exportProfile, icon: const Icon(Icons.save_alt), label: const Text('Экспорт JSON')))]),
    ])),
    const SizedBox(height: 14), _section('НАЙДЕННЫЕ ОСОБЕННОСТИ', '${_findings.length} МЕСТ'),
    const SizedBox(height: 8), if (_findings.isEmpty) _card(const Text('Пока нет данных. После измерения здесь появятся локальные пики и провалы. Салонные отражения и встроенный микрофон могут создавать ложные особенности.', style: TextStyle(color: Colors.white54, height: 1.4))) else ..._findings.map(_findingCard),
    const SizedBox(height: 12), _warning('Автоматические подсказки не управляют DSP и не являются готовым EQ-профилем. Сначала проверь повторяемость измерения, затем корректируй небольшими шагами. Провал не всегда нужно поднимать эквалайзером.'),
  ]);

  Widget _findingCard(Map<String, dynamic> item) {
    final peak = item['type'] == 'peak';
    return Container(margin: const EdgeInsets.only(bottom: 8), padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(14), border: Border.all(color: (peak ? orange : const Color(0xFF5AA8FF)).withOpacity(.22))), child: Row(children: [
      Icon(peak ? Icons.trending_up : Icons.trending_down, color: peak ? orange : const Color(0xFF5AA8FF)), const SizedBox(width: 12),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('${(item['frequencyHz'] as double).round()} Hz · ${peak ? 'возможный пик' : 'возможный провал'}', style: const TextStyle(fontWeight: FontWeight.bold)), Text('Отклонение ${(item['levelDb'] as double).toStringAsFixed(1)} dB', style: const TextStyle(color: Colors.white54, fontSize: 11))])),
      Text(peak ? 'CUT ${(item['suggestionDb'] as double).toStringAsFixed(1)} dB*' : 'НЕ ПОДНИМАТЬ*', textAlign: TextAlign.end, style: TextStyle(color: peak ? green : Colors.white54, fontSize: 11, fontWeight: FontWeight.bold)),
    ]));
  }

  Widget _delayPage() => ListView(padding: const EdgeInsets.all(16), children: [
    _section('ВРЕМЕННЫЕ ЗАДЕРЖКИ', 'ПО РАССТОЯНИЮ'),
    const SizedBox(height: 10), _card(Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('Измерь расстояние от точки прослушивания до каждого динамика. Приложение считает относительную задержку относительно ближайшего динамика.', style: TextStyle(color: Colors.white60, height: 1.4)),
      const SizedBox(height: 10), Row(children: [const Icon(Icons.info_outline, color: orange, size: 18), const SizedBox(width: 8), Expanded(child: Text('Скорость звука принята 343 м/с. Это стартовый расчёт, не измерение импульсного отклика.', style: TextStyle(color: orange.withOpacity(.9), fontSize: 11)))]),
      const SizedBox(height: 12), ..._distances.keys.map((channel) => Padding(padding: const EdgeInsets.symmetric(vertical: 5), child: Row(children: [SizedBox(width: 54, child: Text(channel, style: const TextStyle(fontWeight: FontWeight.bold))), Expanded(child: Slider(value: _distances[channel]!.clamp(30, 250).toDouble(), min: 30, max: 250, onChanged: (v) => setState(() => _distances[channel] = v))), SizedBox(width: 60, child: Text('${_distances[channel]!.round()} cm', textAlign: TextAlign.end, style: const TextStyle(fontSize: 12)))]))),
    ])),
    const SizedBox(height: 10), _card(Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('РАСЧЁТ ДЛЯ DSP', style: TextStyle(color: orange, fontSize: 11, fontWeight: FontWeight.w900, letterSpacing: 1.2)), const SizedBox(height: 8), ..._distances.entries.map((e) => Padding(padding: const EdgeInsets.symmetric(vertical: 5), child: Row(children: [Expanded(child: Text(e.key)), Text('${_delayMs(e.value).toStringAsFixed(2)} ms', style: TextStyle(fontWeight: FontWeight.bold, color: _delayMs(e.value) < .01 ? green : Colors.white))]))), const SizedBox(height: 8), SizedBox(width: double.infinity, child: OutlinedButton.icon(onPressed: _exportProfile, icon: const Icon(Icons.file_download_outlined), label: const Text('ЭКСПОРТИРОВАТЬ РАСЧЁТ'))])),
    const SizedBox(height: 12), _warning('Важно: задержки по расстоянию дают только начальную настройку. Финальная настройка требует измерения импульсного отклика/времени прихода сигнала и проверки на слух. Приложение не подключено напрямую к Hellion или STORM DSP.'),
  ]);

  Widget _section(String title, String trailing) => Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Expanded(child: Text(title, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w900, letterSpacing: 1.1))), Text(trailing, style: const TextStyle(fontSize: 10, color: orange, fontWeight: FontWeight.bold))]);
  Widget _card(Widget child) => Container(padding: const EdgeInsets.all(15), decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(17), border: Border.all(color: Colors.white.withOpacity(.05))), child: child);
  Widget _signalInfo(String title, String description, IconData icon) => Container(margin: const EdgeInsets.only(top: 7), padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(13)), child: Row(children: [Icon(icon, color: orange), const SizedBox(width: 10), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)), const SizedBox(height: 3), Text(description, style: const TextStyle(color: Colors.white54, fontSize: 11, height: 1.35))]))]));
  Widget _warning(String text) => Container(padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: const Color(0xFF2B2419), borderRadius: BorderRadius.circular(14), border: Border.all(color: orange.withOpacity(.22))), child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [const Icon(Icons.warning_amber_rounded, color: orange), const SizedBox(width: 10), Expanded(child: Text(text, style: const TextStyle(color: Colors.white70, fontSize: 11, height: 1.45)))]));
}
